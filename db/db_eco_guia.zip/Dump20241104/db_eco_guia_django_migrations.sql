CREATE DATABASE  IF NOT EXISTS `db_eco_guia` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_eco_guia`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_eco_guia
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2024-09-19 23:03:46.877030'),(2,'auth','0001_initial','2024-09-19 23:03:48.297509'),(3,'admin','0001_initial','2024-09-19 23:03:48.612234'),(4,'admin','0002_logentry_remove_auto_add','2024-09-19 23:03:48.622262'),(5,'admin','0003_logentry_add_action_flag_choices','2024-09-19 23:03:48.630320'),(6,'contenttypes','0002_remove_content_type_name','2024-09-19 23:03:48.789539'),(7,'auth','0002_alter_permission_name_max_length','2024-09-19 23:03:48.948576'),(8,'auth','0003_alter_user_email_max_length','2024-09-19 23:03:49.087519'),(9,'auth','0004_alter_user_username_opts','2024-09-19 23:03:49.094403'),(10,'auth','0005_alter_user_last_login_null','2024-09-19 23:03:49.207386'),(11,'auth','0006_require_contenttypes_0002','2024-09-19 23:03:49.211350'),(12,'auth','0007_alter_validators_add_error_messages','2024-09-19 23:03:49.226079'),(13,'auth','0008_alter_user_username_max_length','2024-09-19 23:03:49.369448'),(14,'auth','0009_alter_user_last_name_max_length','2024-09-19 23:03:49.525581'),(15,'auth','0010_alter_group_name_max_length','2024-09-19 23:03:49.669444'),(16,'auth','0011_update_proxy_permissions','2024-09-19 23:03:49.679396'),(17,'auth','0012_alter_user_first_name_max_length','2024-09-19 23:03:49.849419'),(18,'sessions','0001_initial','2024-09-19 23:03:49.939647'),(19,'app_eco_guia','0001_initial','2024-09-19 23:24:12.924083'),(20,'app_eco_guia','0002_imagehistory','2024-09-26 00:40:06.906213'),(21,'app_eco_guia','0003_delete_imagehistory','2024-09-26 00:40:06.955027'),(22,'app_eco_guia','0003_reclamacoes','2024-10-10 17:00:07.917494'),(23,'app_eco_guia','0004_alter_reclamacoes_remail','2024-10-10 17:00:07.988164'),(24,'app_eco_guia','0005_categorias_ideias','2024-10-10 17:00:08.270610'),(25,'app_eco_guia','0006_rename_categorias_categoria_rename_ideias_ideia_and_more','2024-10-10 17:00:08.841968'),(26,'app_eco_guia','0007_ideia_resumo','2024-10-10 17:00:09.026767');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-04  9:45:28
