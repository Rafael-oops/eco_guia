CREATE DATABASE  IF NOT EXISTS `db_eco_guia` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_eco_guia`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_eco_guia
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('3jreiyvgo6r299usez8qdml3fe7ohypa','.eJxVjMsOwiAQRf-FtSHAwAAu3fsNZHhJ1dCktCvjv2uTLnR7zzn3xQJtawvbKEuYMjszyU6_W6T0KH0H-U79NvM093WZIt8VftDBr3Muz8vh_h00Gu1bU65CeUJpAZSEFHVBhcJWJE0u2ei0N0IAOEHeIWDOEouJoGs02nr2_gDFKjbj:1stcDu:GU-YS7hBfJ-_W1FWG5INCUGA_oC9UCM5epJQ65D2uDs','2024-10-10 00:19:10.072736'),('5lq213mw32yn4381sw5zfx8od2pncsnb','.eJxVjMsOwiAUBf-FtSFAy6Mu3fsNhPtAqgaS0q6M_65NutDtmZnzEjFta4lb5yXOJM5Ci9PvBgkfXHdA91RvTWKr6zKD3BV50C6vjfh5Ody_g5J6-daj1WYKbjDWwpiyUpkMWTVA0JBDRp9Y-wA0MWVtUaFj1gMph-QtIYj3B9oZOIk:1srQEZ:x5qNskTUiP9qMMMk7rkrcytU_QdgB4guW6ayQbyPrKM','2024-10-03 23:06:47.101877'),('5qbtilkvabbwpmyqsivu5j59dtve6y1c','.eJxVjDkOwjAURO_iGln2905JnzNY3xsOIEeKkwpxdxwpBXSjeW_mTTzuW_V7z6ufE7kSTi6_XcD4zO0A6YHtvtC4tG2dAz0UetJOpyXl1-10_w4q9jrWWnPILBltlBFOiFBsUTqFEblwEgBZBKURSmTSWgdyKE6bAoaJkh35fAGugDaZ:1t7uzS:XRbJ4bhdAxJ5P5MHz-L1BCjC_ItqSESb-OLM-ATVydE','2024-11-18 11:11:22.447924'),('tqjmcm4dub3jxqs04do3bshnz9kuhdni','.eJxVjDkOwjAURO_iGln2905JnzNY3xsOIEeKkwpxdxwpBXSjeW_mTTzuW_V7z6ufE7kSTi6_XcD4zO0A6YHtvtC4tG2dAz0UetJOpyXl1-10_w4q9jrWWnPILBltlBFOiFBsUTqFEblwEgBZBKURSmTSWgdyKE6bAoaJkh35fAGugDaZ:1t7vwH:x82nYxEs9uN4H_gX5NSM4AQU-cjmxc_XjaQDgTJBT6k','2024-11-18 12:12:09.043828');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-04  9:45:28
